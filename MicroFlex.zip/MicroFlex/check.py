import os

def search_for_word(directory, keyword):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith(".py"):  # Adjust the extension based on your script files
                script_path = os.path.join(root, file)
                with open(script_path, 'r') as f:
                    content = f.read()
                    if keyword in content:
                        print(f'Found in {script_path}')

# Example usage:
search_for_word('/sdcard/download/MicroFlex/MicroFlex', 'THIS IS SIMPLE BY DPK BOT')
